# TO DO:
# ADD MMA
# FIX PAGE


#lazy code incoming
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import sys
import requests
import urllib.parse
import re
import resolveurl

nfl_url = 'https://nfl-replays.com/?page%s'
mlb_url = 'https://mlblive.net/?page%s'
nba_url = 'https://basketballreplays.net/?page%s' 
nhl_url = 'https://nhlfullgame.com/?page%s'
wwe_url = 'https://1max.top/category/_wrestling_main/page/%s/'
boxing_url = 'https://fullfightreplays.com/boxing?page%s'
ufc_url = 'https://fullfightreplays.com/ufc?page%s'
soccer_url = 'https://soccerfull.net/new/%s'
f1_url = 'https://f1fullraces.com/watch-f1-free/category/full-races/page/%s/'

addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo('name')
addon_icon = addon.getAddonInfo('icon')
addon_fanart = addon.getAddonInfo('fanart')
addon_handle = int(sys.argv[1])
user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36'

def original_url(x): 
    return 'https://' + x.split('/')[2]

def log(msg,lvl=xbmc.LOGWARNING):
    m = f'Breach Sports - ({sys.argv[0]}): {msg}'
    xbmc.log(m,lvl)

def addDir(name,url,mode,icon,fanart='',page=1):
    u = sys.argv[0] + '?url=' + urllib.parse.quote_plus(url) + '&mode=' + str(mode) + '&name=' + urllib.parse.quote_plus(name) + '&page=' + str(page)
    liz = xbmcgui.ListItem(name)
    liz.setArt({'icon': addon_icon, 'fanart': fanart})
    add = xbmcplugin.addDirectoryItem(handle=addon_handle,url=u,listitem=liz,isFolder=True)
    return add

def addVideo(name,url,mode,icon,fanart='',date='',page=1):
    u = sys.argv[0] + '?url=' + urllib.parse.quote_plus(url) + '&mode=' + str(mode) + '&name=' + urllib.parse.quote_plus(name) + '&page=' + str(page)
    liz = xbmcgui.ListItem(name)
    liz.setArt({'icon': icon, 'fanart': fanart})
    liz.setInfo('video',infoLabels={'title': name, 'date': date})
    add = xbmcplugin.addDirectoryItem(handle=addon_handle,url=u,listitem=liz,isFolder=False)
    return add

def real_title(title,sportname=''):
    date = re.search(r'(\d{1,2} \w+ \d{4})',title,re.DOTALL)
    if date: title = title.replace(date.group(),'')
    date = re.search(r'(\d{1,2})/{\d{1,2}}/\d{2}',title,re.DOTALL)
    if date: title = title.replace(date.group(),'')
    date = re.search(r'(?:January|February|March|April|May|June|July|August|September|October|November|December) \d{1,2}, \d{4}',title,re.DOTALL)
    if date: title = title.replace(date.group(),'')
    #date = re.search(r'(\d{1,2})\w+ (?:January|February|March|April|May|June|July|August|September|October|November|December) \d{4}',title,re.DOTALL)
    #if date: title = title.replace(date.group(),'')
    if sportname: 
        title = title.split(sportname)[0]
    else: 
        if 'Full' in title: title = title.split('Full')[0]
    title = title.replace('&#39;','\'')
    title = title.replace('&#8211;','-')
    return title

def fix_link(link):
    link = original_url(link)
    return link


#date sometimes in title name.
def get_date(title):
    date = re.search(r'(\d{1,2} \w+ \d{4})',title,re.DOTALL)
    if date:
        date = date.group(1)
        return date
    date = re.search(r'(\d{1,2})/{\d{1,2}}/\d{2}',title,re.DOTALL)
    if date:
        date = date.group(1)
        return date
    date = re.search(r'(?:January|February|March|April|May|June|July|August|September|October|November|December) \d{1,2}, \d{4}',title,re.DOTALL)
    if date:
        date = date.group()
        return date
    return 'Unknown Date'


def play_video():
    streams = []
    dialog = xbmcgui.Dialog()
    log(url,xbmc.LOGWARNING)
    headers = {'User-Agent': user_agent,'Content-Type': 'video/mp4','Connection': 'keep-alive'}
    r = requests.get(url,headers=headers)
    text = r.text
    iframe = re.findall(r'<div\s+class="video-responsive"[^>]*><iframe[^>]*src="(.*?)"\s*</div>',text,re.DOTALL)
    if not iframe:
        iframe = re.findall(r'<iframe src="(.*?)"',text,re.DOTALL)
    if not iframe:
        iframe = re.findall(r'<iframe allowfullscreen[^>]*src="(.*?)"',text,re.DOTALL)
    if not iframe:
        iframe = re.findall(r'data-sc="(.*?)"',text,re.DOTALL)
    for i in iframe:
        streams.append({'name': original_url(i).replace('https://','').upper(),'link': i})
    call = dialog.select('Select a stream',[stream['name'] for stream in streams])
    if call == -1: return
    #log(call,xbmc.LOGWARNING)
    resolved_url = resolveurl.resolve(streams[call]['link'])
    #log(resolved_url,xbmc.LOGWARNING)
    item = xbmcgui.ListItem(offscreen=True,label=name)
    requests.get(resolved_url,headers=headers)
    #item.setPath(resolved_url)
    #xbmcplugin.setResolvedUrl(addon_handle,True,listitem=item)
    player = xbmc.Player()
    player.play(resolved_url,listitem=item)

def main_menu():
    xbmcplugin.setPluginCategory(addon_handle,addon_name)
    xbmcplugin.setContent(addon_handle,addon_name)
    addDir('NFL',nfl_url,1,addon_icon)
    addDir('NBA',nba_url,2,addon_icon)
    addDir('NHL',nhl_url,3,addon_icon)
    addDir('WWE',wwe_url,4,addon_icon)
    addDir('UFC',ufc_url,6,addon_icon)
    addDir('Soccer',soccer_url,7,addon_icon)
    addDir('F1',f1_url,8,addon_icon)
    addDir('MLB',mlb_url,9,addon_icon)
    addDir('Boxing',boxing_url,10,addon_icon)
    xbmcplugin.endOfDirectory(addon_handle)

def nfl_menu():
    sport_name = 'NFL'
    base_url = ''
    title = ''
    date = ''
    image = ''
    videos = []
    base_url = url % (page)
    #log(base_url,xbmc.LOGWARNING)
    headers = {'User-Agent': user_agent, 'Connection': 'keep-alive','Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'}
    resp = requests.get(base_url,headers=headers,timeout=15,stream=True)
    if resp.status_code == 200:
        text = resp.text
        if text:
            items = re.compile(r'<div\s+class="short_item block_elem">(.*?)</div>\s*</div>',re.DOTALL).findall(text)
            for i in items:
                link = re.compile(r'href="(.*?)"',re.DOTALL).search(i).group(1)
                title = re.compile(r'<h3><a.*?>(.*?)</a></h3>',re.DOTALL).search(i).group(1)
                date = get_date(title)
                image = re.compile(r'<img\ssrc="(.*?)"',re.DOTALL).search(i).group(1)
                title = real_title(title,sport_name)
                if 'Unknown Date' in date: title = '{}'.format(title.replace(date,''),date)
                else: title = '{} | [B]{}[/B]'.format(title.replace(date,''),date)
                videos.append({'title': title,'link': link,'image': image,'date': date})
    xbmcplugin.setPluginCategory(addon_handle,sport_name)
    xbmcplugin.setContent(addon_handle,sport_name)
    if page > '1': 
        addDir('[B]Previous Page[/B]',nfl_url,mode,addon_icon,addon_fanart,int(page)-1)
    log(original_url(url),xbmc.LOGWARNING)
    for v in videos: 
        n_url = original_url(url)
        log(n_url,xbmc.LOGWARNING)
        addVideo(v['title'],n_url + v['link'],15,n_url + v['image'],url + v['image'],v['date'])
    addDir('[B]Next Page ({})[/B]'.format(int(page) + 1),nfl_url,mode,addon_icon,addon_fanart,page=int(page)+1)
    xbmcplugin.endOfDirectory(addon_handle)

def mlb_menu():
    sport_name = 'MLB'
    base_url = ''
    title = ''
    date = ''
    image = ''
    videos = []
    base_url = url % (page)
    #log(base_url,xbmc.LOGWARNING)
    headers = {'User-Agent': user_agent, 'Connection': 'keep-alive'}
    resp = requests.get(base_url,headers=headers,timeout=15)
    if resp.status_code == 200:
        text = resp.text
        if text:
            items = re.compile(r'<div\s+class="short_item block_elem">(.*?)</div>\s*</div>',re.DOTALL).findall(text)
            for i in items:
                link = re.compile(r'href="(.*?)"',re.DOTALL).search(i).group(1)
                title = re.compile(r'<h3><a.*?>(.*?)</a></h3>',re.DOTALL).search(i).group(1)
                date = get_date(title)
                image = re.compile(r'<img\ssrc="(.*?)"',re.DOTALL).search(i).group(1)
                title = real_title(title)
                if 'Unknown Date' in date: title = '{}'.format(title.replace(date,''),date)
                else: title = '{} | [B]{}[/B]'.format(title.replace(date,''),date)
                videos.append({'title': title,'link': link,'image': image,'date': date})
    xbmcplugin.setPluginCategory(addon_handle,sport_name)
    xbmcplugin.setContent(addon_handle,sport_name)
    if page > '1': 
        addDir('[B]Previous Page[/B]',mlb_url,mode,addon_icon,addon_fanart,int(page)-1)
    log(original_url(url),xbmc.LOGWARNING)
    for v in videos: 
        n_url = original_url(url)
        addVideo(v['title'],n_url + v['link'],15,n_url + v['image'],url + v['image'],v['date'])
    addDir('[B]Next Page ({})[/B]'.format(int(page) + 1),mlb_url,mode,addon_icon,addon_fanart,page=int(page)+1)
    xbmcplugin.endOfDirectory(addon_handle)

def nba_menu():
    sport_name = 'NBA'
    base_url = ''
    title = ''
    date = ''
    image = ''
    videos = []
    base_url = url % (page)
    #log(base_url,xbmc.LOGWARNING)
    resp = requests.get(base_url,headers={'User-Agent': user_agent})
    if resp.status_code == 200:
        text = resp.text
        if text:
            #items = re.compile(r'<div class="h_post_title">(.*?)</div>',re.DOTALL).findall(text)
            items = re.compile(r'<div\s+class="h_post">(.*?)</div>\s*</div>',re.DOTALL).findall(text)
            for i in items:
                link = re.compile(r'href="(.*?)"',re.DOTALL).search(i).group(1)
                title = re.compile(r'_title"><a.*?>(.*?)</a>',re.DOTALL).search(i).group(1)
                image = re.compile(r'<img\s+src="(.*?)"',re.DOTALL).search(i).group(1)
                date = get_date(title)
                title = real_title(title,sport_name)
                if 'Unknown Date' in date: title = '{}'.format(title.replace(date,''),date)
                else: title = '{} | [B]{}[/B]'.format(title.replace(date,''),date)
                videos.append({'title': title,'link': link,'image': image,'date': date})
    xbmcplugin.setPluginCategory(addon_handle,sport_name)
    xbmcplugin.setContent(addon_handle,sport_name)
    if page > '1': 
        addDir('[B]Previous Page[/B]',nba_url,mode,addon_icon,addon_fanart,int(page)-1)
    for v in videos:
        n_url = original_url(url)
        addVideo(v['title'],n_url + v['link'],15,n_url + v['image'],url + v['image'],v['date'])
    addDir('[B]Next Page ({})[/B]'.format(int(page) + 1),nba_url,mode,addon_icon,addon_fanart,page=int(page)+1)
    xbmcplugin.endOfDirectory(addon_handle)

def nhl_menu():
    sport_name = 'NHL'
    base_url = ''
    title = ''
    date = ''
    image = ''
    videos = []
    base_url = url % (page)
    #log(base_url,xbmc.LOGWARNING)
    resp = requests.get(base_url,headers={'User-Agent': user_agent})
    if resp.status_code == 200:
        text = resp.text
        if text:
            items = re.compile(r'<div id="entryID\d+">(.*?)</div>\s*</div>',re.DOTALL).findall(text)
            for i in items:
                link = re.compile(r'href="(.*?)"',re.DOTALL).search(i).group(1)
                title = re.compile(r'<a[^>]*class="entryLink">(.*?)</a>',re.DOTALL).search(i).group(1)
                image = re.compile(r'<img\s+src="(.*?)"',re.DOTALL).search(i).group(1)
                #link = original_url(link)
                date = get_date(title)
                title = real_title(title,sport_name)
                if 'Unknown Date' in date: title = '{}'.format(title.replace(date,''),date)
                else: title = '{} | [B]{}[/B]'.format(title.replace(date,''),date)
                videos.append({'title': title,'link': link,'image': image,'date': date})
    xbmcplugin.setPluginCategory(addon_handle,sport_name)
    xbmcplugin.setContent(addon_handle,sport_name)
    if page > '1': 
        addDir('[B]Previous Page[/B]',nhl_url,mode,addon_icon,addon_fanart,int(page)-1)
    for v in videos: 
        addVideo(v['title'],original_url(url) + v['link'],15,'https://'+url.split('/')[2] + v['image'],url + v['image'],v['date'])
    addDir('[B]Next Page ({})[/B]'.format(int(page) + 1),nhl_url,mode,addon_icon,addon_fanart,page=int(page)+1)
    xbmcplugin.endOfDirectory(addon_handle)

def wwe_menu():
    sport_name = 'WWE'
    base_url = ''
    title = ''
    date = ''
    image = ''
    videos = []
    base_url = url % (page)
    #log(base_url,xbmc.LOGWARNING)
    resp = requests.get(base_url,headers={'User-Agent': user_agent})
    if resp.status_code == 200:
        text = resp.text
        if text:
            items = re.compile(r'<div\s+id="post-\d+"[^>]*>(.*?)</div>\s*</div>',re.DOTALL).findall(text)
            for i in items:
                link = re.compile(r'href="(.*?)">',re.DOTALL).search(i).group(1)
                title = re.compile(r'title="(.*?)"',re.DOTALL).search(i).group(1)
                title = real_title(title)
                image = re.compile(r'<img src="(.*?)"',re.DOTALL).search(i).group(1)
                date = re.compile(r'<time[^>]*>(.*?)</time>').search(i).group(1)
                if 'Unknown Date' in date: title = '{}'.format(title.replace(date,''),date)
                else: title = '{} | [B]{}[/B]'.format(title.replace(date,''),date)
                videos.append({'title': title,'link': link,'image': image,'date': date})
    xbmcplugin.setPluginCategory(addon_handle,sport_name)
    xbmcplugin.setContent(addon_handle,sport_name)
    if page > '1': 
        addDir('[B]Previous Page[/B]',wwe_url,mode,addon_icon,addon_fanart,int(page)-1)
    for v in videos: 
        if original_url(url) in v['link']: addVideo(v['title'],url + v['link'],15,original_url(v['image']),url + v['image'],v['date'])
    addDir('[B]Next Page ({})[/B]'.format(int(page) + 1),wwe_url,mode,addon_icon,addon_fanart,page=int(page)+1)
    xbmcplugin.endOfDirectory(addon_handle)

def boxing_menu():
    sport_name = 'Boxing'
    base_url = ''
    title = ''
    date = ''
    image = ''
    videos = []
    base_url = url % (page)
    #log(base_url,xbmc.LOGWARNING)
    headers = {'User-Agent': user_agent, 'Connection': 'keep-alive'}
    resp = requests.get(base_url,headers=headers,timeout=15)
    if resp.status_code == 200:
        text = resp.text
        if text:
            items = re.compile(r'<div\s+class="short_item block_elem">(.*?)</div>\s*</div>',re.DOTALL).findall(text)
            for i in items:
                link = re.compile(r'href="(.*?)"',re.DOTALL).search(i).group(1)
                title = re.compile(r'<h3><a.*?>(.*?)</a></h3>',re.DOTALL).search(i).group(1)
                date = get_date(title)
                image = re.compile(r'<img\ssrc="(.*?)"',re.DOTALL).search(i).group(1)
                title = real_title(title,sport_name)
                if 'Unknown Date' or '' in date: title = '{}'.format(title.replace(date,''),date)
                else: title = '{} | [B]{}[/B]'.format(title.replace(date,''),date)
                videos.append({'title': title,'link': link,'image': image,'date': date})
    xbmcplugin.setPluginCategory(addon_handle,sport_name)
    xbmcplugin.setContent(addon_handle,sport_name)
    if page > '1': 
        addDir('[B]Previous Page[/B]',boxing_url,mode,addon_icon,addon_fanart,int(page)-1)
    #log(original_url(url),xbmc.LOGWARNING)
    for v in videos: 
        n_url = original_url(url)
        log(n_url,xbmc.LOGWARNING)
        addVideo(v['title'],n_url + v['link'],15,n_url + v['image'],url + v['image'],v['date'])
    addDir('[B]Next Page ({})[/B]'.format(int(page) + 1),boxing_url,mode,addon_icon,addon_fanart,page=int(page)+1)
    xbmcplugin.endOfDirectory(addon_handle)

def ufc_menu():
    sport_name = 'UFC'
    base_url = ''
    title = ''
    date = ''
    image = ''
    videos = []
    base_url = url % (page)
    #log(base_url,xbmc.LOGWARNING)
    headers = {'User-Agent': user_agent, 'Connection': 'keep-alive'}
    resp = requests.get(base_url,headers=headers,timeout=15)
    if resp.status_code == 200:
        text = resp.text
        if text:
            items = re.compile(r'<div\s+class="short_item block_elem">(.*?)</div>\s*</div>',re.DOTALL).findall(text)
            for i in items:
                link = re.compile(r'href="(.*?)"',re.DOTALL).search(i).group(1)
                title = re.compile(r'<h3><a.*?>(.*?)</a></h3>',re.DOTALL).search(i).group(1)
                date = get_date(title)
                image = re.compile(r'<img\ssrc="(.*?)"',re.DOTALL).search(i).group(1)
                title = real_title(title)
                if 'Unknown Date' or '' in date: title = '{}'.format(title.replace(date,''),date)
                else: title = '{} | [B]{}[/B]'.format(title.replace(date,''),date)
                videos.append({'title': title,'link': link,'image': image,'date': date})
    xbmcplugin.setPluginCategory(addon_handle,sport_name)
    xbmcplugin.setContent(addon_handle,sport_name)
    if page > '1': 
        addDir('[B]Previous Page[/B]',ufc_url,mode,addon_icon,addon_fanart,int(page)-1)
    #log(original_url(url),xbmc.LOGWARNING)
    for v in videos: 
        n_url = original_url(url)
        #log(n_url,xbmc.LOGWARNING)
        addVideo(v['title'],n_url + v['link'],15,n_url + v['image'],url + v['image'],v['date'])
    addDir('[B]Next Page ({})[/B]'.format(int(page) + 1),ufc_url,mode,addon_icon,addon_fanart,page=int(page)+1)
    xbmcplugin.endOfDirectory(addon_handle)

def soccer_menu():
    sport_name = 'Soccer'
    base_url = ''
    title = ''
    date = ''
    image = ''
    videos = []
    base_url = url % (page)
    #log(base_url,xbmc.LOGWARNING)
    resp = requests.get(base_url,headers={'User-Agent': user_agent})
    if resp.status_code == 200:
        text = resp.text
        if text:
            items = re.compile(r'<li\s+class="item-movie">(.*?)</li>',re.DOTALL).findall(text)
            for i in items:
                link = re.compile(r'href="(.*?)"',re.DOTALL).search(i).group(1)
                title = re.compile(r'title="(.*?)"',re.DOTALL).search(i).group(1)
                title = title.replace('&#8211;','-')
                image = re.compile(r'<img[^>]*src="(.*?)"',re.DOTALL).search(i).group(1)
                title = real_title(title)
                if 'Unknown Date' or '' in date: title = '{}'.format(title.replace(date,''),date)
                else: title = '{} | [B]{}[/B]'.format(title.replace(date,''),date)
                videos.append({'title': title,'link': link,'image': image,'date': date})
    xbmcplugin.setPluginCategory(addon_handle,sport_name)
    xbmcplugin.setContent(addon_handle,sport_name)
    if page > '1': 
        addDir('[B]Previous Page[/B]',soccer_url,mode,addon_icon,addon_fanart,int(page)-1)
    for v in videos: addVideo(v['title'],original_url(url) + v['link'],15,v['image'],addon_fanart,v['date'])
    addDir('[B]Next Page ({})[/B]'.format(int(page) + 1),soccer_url,mode,addon_icon,addon_fanart,page=int(page)+1)
    xbmcplugin.endOfDirectory(addon_handle)

def f1_menu():
    sport_name = 'F1'
    base_url = ''
    title = ''
    date = ''
    image = ''
    videos = []
    base_url = url % (page)
    #log(base_url,xbmc.LOGWARNING)
    resp = requests.get(base_url,headers={'User-Agent': user_agent})
    if resp.status_code == 200:
        text = resp.text
        if text:
            items = re.compile(r'<article[^>]*>(.*?)</article>',re.DOTALL).findall(text)
            for i in items:
                link = re.compile(r'href="(.*?)"',re.DOTALL).search(i).group(1)
                title = re.compile(r'"bookmark">(.*?)</a>',re.DOTALL).search(i).group(1)
                title = title.replace('&#8211;','-')
                date = re.compile(r'<li\s+class="entry-date"><i[^>]*></i>(.*?)</li>').search(i).group(1)
                image = re.compile(r'<img[^>]*src="(.*?)"',re.DOTALL).search(i).group(1)
                title = real_title(title)
                if 'Unknown Date' or '' in date: title = '{}'.format(title.replace(date,''),date)
                else: title = '{} | [B]{}[/B]'.format(title.replace(date,''),date)
                videos.append({'title': title,'link': link,'image': image,'date': date})
    xbmcplugin.setPluginCategory(addon_handle,sport_name)
    xbmcplugin.setContent(addon_handle,sport_name)
    if page > '1': 
        addDir('[B]Previous Page[/B]',f1_url,mode,addon_icon,addon_fanart,int(page)-1)
    for v in videos: addVideo(v['title'],url + v['link'],15,v['image'],addon_fanart,v['date'])
    addDir('[B]Next Page ({})[/B]'.format(int(page) + 1),f1_url,mode,addon_icon,addon_fanart,page=int(page)+1)
    xbmcplugin.endOfDirectory(addon_handle)


params = urllib.parse.parse_qs(sys.argv[2][1:])
mode = params.get('mode',[None])[0] #mode=['1']
url = params.get('url',[None])[0]
name = params.get('name',[None])[0]
page = params.get('page',[None])[0]

if not mode or mode == 0:
    main_menu()
elif mode == '1':#nfl
    nfl_menu()
elif mode == '2':#nba
    nba_menu()
elif mode == '3':#nhl
    nhl_menu()
elif mode == '4':#wwe
    wwe_menu()
elif mode == '6':#ufc
    ufc_menu()
elif mode == '7':#soccer
    soccer_menu()
elif mode == '8':#f1
    f1_menu()
elif mode == '9':#mlb
    mlb_menu()
elif mode == '10':#boxing
    boxing_menu()
elif mode == '15':#play video
    play_video()
elif mode == '11':
    pass
else: 
    pass
