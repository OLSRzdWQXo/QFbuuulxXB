import traceback
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import sys
import re
import bs4
import urllib.parse
import requests
import string
from datetime import datetime
import json

headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36'}
base_url='https://www.hockeyfights.com'
addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo('name')
addon_icon = addon.getAddonInfo('icon')
addon_id = addon.getAddonInfo('id')
curyear = datetime.now().year

def addLink(name, url, desc='', icon='DefaultFolder.png', fanart='', isFolder=True):
    u = sys.argv[0] + '?action=%s' % url
    li = xbmcgui.ListItem(label=name)
    li.setArt({'thumb':icon, 'icon': icon, 'fanart': fanart})
    li.setInfo('video', infoLabels={'plot': desc})
    xbmcplugin.addDirectoryItem(int(sys.argv[1]), u, listitem=li, isFolder=isFolder)


def play_video():
    player=xbmc.Player()
    resolved=None
    direct_video_url=None
    ydl_opts={
        'quiet':True,
        'no_warnings':True,
        'skip_download':True,
        'nocheckcertificate': True,
        'format':'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best',
    }
    try:
        r = requests.get(url, headers=headers)
        r.raise_for_status()
    except:
        traceback.print_exc()
        return
    embed_id = re.search(r'https://www\.youtube\.com/embed/([A-Za-z0-9_-]+)', r.text, re.DOTALL)
    if embed_id:
        embed_id = embed_id.group(1)
    yt_url = embed_id
    from youtube_dl import YoutubeDL
    try:
        with YoutubeDL(ydl_opts) as ydl:
            info=ydl.extract_info(yt_url,download=False)
        for f in info.get('formats',[]):
            if f.get('ext')=='mp4':
                direct_video_url=f.get('url')
    except Exception:
        traceback.print_exc()
        return
    title=info.get('title','')
    li=xbmcgui.ListItem(label=title,path=direct_video_url)
    li.setInfo('video',{'title':title})
    li.setProperty('isPlayable','true')
    player.play(direct_video_url,li)
    return


def fightlog():
    global year,page
    page=int(page)
    fightlog_url='https://www.hockeyfights.com/fightlog/1/reg{}/{}'.format(year,page)
    videos=[]
    try:
        r = requests.get(fightlog_url, headers=headers)
        r.raise_for_status()
    except:
        traceback.print_exc()
        return
    xbmcplugin.setPluginCategory(int(sys.argv[1]), 'Page [B]%s[/B]'%page)
    xbmcplugin.setContent(int(sys.argv[1]), 'Page [B]%s[/B]'%page)
    soup = bs4.BeautifulSoup(r.text, 'html.parser')
    if soup:
        if page > 1: 
            addLink('[B]Last Page ({})[/B]'.format(page-1), 'fightlog&page=%s&year=%s'%(page+1,year))
        for i in soup.find_all('div', attrs={'class': 'flex w-full flex-col gap-4 md:flex-row'}):
            name = i.find('span', attrs={'class': 'text-xl font-bold text-gray-800 dark:text-gray-50'}).text
            link  = urllib.parse.urljoin(base_url, i.find('a')['href'])
            poster = urllib.parse.urljoin(base_url, i.find('img')['src'])
            desc = '[B]' + '\n'.join(x.text for x in i.find_all('span', attrs={'class': 'text-sm text-gray-500'})) + '[/B]'

            addLink(name, 'playvideo&url={}'.format(link), desc, poster, poster, isFolder=False)
        addLink('[B]Next Page ({})[/B]'.format(page+1), 'fightlog&page=%s&year=%s'%(page+1,year))

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def search_year():
    xbmcplugin.setPluginCategory(int(sys.argv[1]), 'Search by year')
    xbmcplugin.setContent(int(sys.argv[1]), 'Search by year')
    for yr in range(curyear,2000,-1):
        addLink('%s'%yr,'fightlog&year=%s&page=1'%yr)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def main():
    xbmcplugin.setPluginCategory(int(sys.argv[1]), addon_name)
    xbmcplugin.setContent(int(sys.argv[1]), addon_name)

    addLink('Fightlog', 'fightlog', '[B]Check the fightlog[/B]', addon_icon, isFolder=True)
    addLink('Search by year', 'search_year', '[B]Search by year[/B]', addon_icon, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

try:
    params=dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    #xbmc.log(str(params),xbmc.LOGINFO)
except:
    params={}

action = params.get('action','')
url = params.get('url', '')
name = params.get('name','')
year = int(params.get('year',curyear))
page = params.get('page',1)

if __name__ == "__main__":
    if params:
        if action == 'fightlog':
            fightlog()
        if action == 'playvideo':
            play_video()
        if action == 'search_year':
            search_year()
    else:
        main()
