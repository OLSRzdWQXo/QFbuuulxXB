from urllib.parse import urlencode,parse_qsl,quote
import xbmc
import xbmcaddon
import xbmcplugin
import xbmcgui
import requests
import re
import sys
import json
import os

addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo('path')
addon_icon = addon.getAddonInfo('icon')
addon_name = addon.getAddonInfo('name')
addon_handle = int(sys.argv[1])
addon_plugin = sys.argv[0]
site_url = 'https://worldstarhiphop.com/'
videos = []
user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.6422.112 Safari/537.36'

def build_url(**kwargs):
    return "{}?{}".format(addon_plugin,urlencode(kwargs))

def add_dir(name,url,icon=addon_icon,fanart=''):
    item=xbmcgui.ListItem(label=name)
    item.setArt({'icon': icon,'fanart': fanart,'poster': icon}) 
    xbmcplugin.addDirectoryItem(addon_handle,url,item,isFolder=True)

def add_video(name,url,desc='',icon="DefaultFolder.png",fanart=''):
    item = xbmcgui.ListItem(label=name,offscreen=True)
    item.setArt({'icon': icon,'fanart': fanart})
    #item.setInfo('video', {'title': name, 'tagline': desc})
    item.setProperty('IsPlayable','true')
    xbmcplugin.addDirectoryItem(addon_handle,url,item,isFolder=False)

def play_video(params):
    url = params['url']
    item = xbmcgui.ListItem(offscreen=True,label=params['name'])
    p = requests.get(url,headers={'User-Agent': user_agent},timeout=10)
    item.setPath(url)
    item.setMimeType('video/mp4')
    #item.setContentLookup(False)
    xbmcplugin.setResolvedUrl(addon_handle,True,listitem=item)


def get_listings(url):
    r = requests.get(url)
    text = r.text
    cat = re.compile(r'<script id="__NEXT_DATA__" type="application/json">\s*(.*?)\s*</script>').search(text).group(1)
    js = json.loads(cat)
    return js

def show_listings(params):
    videos = get_listings(params['url'])
    xbmcplugin.setPluginCategory(addon_handle,params['name'])
    xbmcplugin.setContent(addon_handle,params['name'])
    listing = videos['props']['pageProps']['tagVideosInitialResponse']['result']
    for li in listing:
        name = li['title']
        image = li['imageUrl']
        description = li['description']
        url = li['desktopVideoFile']
        add_video(name,build_url(action='play',name=name,url=url),description,image)
    xbmcplugin.endOfDirectory(addon_handle)

def discover_menu(params):
    videos = get_listings(params['url'])
    xbmcplugin.setPluginCategory(addon_handle,'Discover')
    xbmcplugin.setContent(addon_handle,'Discover')
    listing = videos['props']['pageProps']['discoverVideosInitialResponse']['result']
    for li in listing:
        name = li['title']
        image = li['imageUrl']
        description = li['description']
        url = li['desktopVideoFile']
        add_video(name,build_url(action='play',name=name,url=url),description,image)
    xbmcplugin.endOfDirectory(addon_handle)

def categories_menu():
    categories_json = os.path.join(addon_path,'json','categories.json')
    file = open(categories_json,'r')
    entries = json.load(file)
    xbmcplugin.setPluginCategory(addon_handle,addon_name)
    xbmcplugin.setContent(addon_handle,addon_name)
    for entry in entries:
        add_dir(entry['name'],build_url(action='list',name=entry['name'],url=entry['link']))
    xbmcplugin.endOfDirectory(addon_handle)

searched = False
def search_menu():
    global searched
    kb_text = ''
    listing = []
    if searched == False:
        kb = xbmc.Keyboard('','Search')
        kb.doModal()
        if kb.isConfirmed():
            searched = True
            kb_text = kb.getText()
            url = site_url + 'search/' + quote(kb_text)
            videos = get_listings(url)
            listing = videos['props']['pageProps']['nextVideosInitialResponse']['result']
        else:
            xbmcgui.Dialog().notification(addon_name,'Search Cancelled!',addon_icon)
            return
    xbmcplugin.setPluginCategory(addon_handle,f'Showing searches for "{kb_text}"')
    xbmcplugin.setContent(addon_handle,f'Showing searches for "{kb_text}"')
    for li in listing:
        name = li['title']
        image = li['imageUrl']
        description = li['description']
        url = li['desktopVideoFile']
        add_video(name,build_url(action='play',name=name,url=url),description,image)
    xbmcplugin.endOfDirectory(addon_handle)

def main_menu():
    xbmcplugin.setPluginCategory(addon_handle,addon_name)
    xbmcplugin.setContent(addon_handle,addon_name)
    add_dir('Discover',build_url(action='discover',url=site_url + 'discover'))
    add_dir('Categories',build_url(action='categories'))
    add_dir('Search',build_url(action='search')) 
    xbmcplugin.endOfDirectory(addon_handle)

if __name__ == "__main__":
    params = dict(parse_qsl(sys.argv[2][1:]))
    if not params:
        main_menu()
    elif params.get('action') == 'list':
        show_listings(params)
    elif params.get('action') == 'categories':
        categories_menu()
    elif params.get('action') == 'discover':
        discover_menu(params)
    elif params.get('action') == 'search':
        search_menu()
    elif params.get('action') == 'play':
        play_video(params)
